package com.example.petsback.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.petsback.Model.User;

public interface UserRepo extends JpaRepository<User, Long> {
}